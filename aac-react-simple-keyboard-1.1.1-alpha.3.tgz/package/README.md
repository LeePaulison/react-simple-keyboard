## 🛠️ What is This Repo?

This is a **monorepo fork of `react-simple-keyboard` and `simple-keyboard`**, built for internal use, customization, and tighter control over keyboard behavior in React applications.

### Why this exists:

- Both `react-simple-keyboard` and its core dependency `simple-keyboard` are maintained side-by-side in a single repository.
- Enables direct customization and debugging of the core `simple-keyboard` logic without relying on npm-published versions.
- Ideal for monorepo projects, internal demos, or apps requiring fully controlled virtual keyboard behavior.

> 💡 For most use cases, you should use the [official version](https://github.com/hodgef/react-simple-keyboard). This fork is maintained for internal platform needs and rapid iteration.

<a href="https://simple-keyboard.com/demo">
    <img alt="simple-keyboard: Javscript Virtual Keyboard" src="https://user-images.githubusercontent.com/25509135/188000091-fc64ce47-2a87-4835-ab6c-defbaba3ee90.gif">
</a>

<blockquote>Virtual Keyboard for React. Customizable, responsive and lightweight.</blockquote>

<p>
  <a href="https://www.npmjs.com/package/react-simple-keyboard"><img src="https://badgen.net/npm/v/react-simple-keyboard?color=blue" alt="npm version"></a> <a href="https://github.com/hodgef/react-simple-keyboard/blob/master/LICENSE"><img src="https://img.shields.io/badge/License-MIT-blue.svg" alt="MIT license"></a> <a href="https://github.com/hodgef/react-simple-keyboard/actions"><img alt="Build Status" src="https://github.com/hodgef/react-simple-keyboard/workflows/Build/badge.svg?color=green" /></a> <a href="https://github.com/hodgef/react-simple-keyboard/actions"><img alt="Publish Status" src="https://github.com/hodgef/react-simple-keyboard/workflows/Publish/badge.svg?color=green" /></a> <a href="https://gitlab.com/hodgef/react-simple-keyboard"><img alt="Mirroring" src="https://github.com/hodgef/react-simple-keyboard/actions/workflows/mirroring.yml/badge.svg" /></a>
</p>

## 🚀 Demo

[https://simple-keyboard.com/demo](https://simple-keyboard.com/demo)

## 📦 Installation & Usage

Check out the [Getting Started](https://simple-keyboard.com/react/getting-started) docs to begin.

## 📖 Documentation

Check out the [simple-keyboard documentation](https://simple-keyboard.com/react/documentation) site.

Feel free to browse the [Questions & Answers](https://simple-keyboard.com/qa-use-cases/) page for common use-cases.

### To run demo on your own computer

- Clone this repository
- `npm install`
- `npm start`
- Visit [http://localhost:3000/](http://localhost:3000/)

### Other versions

- [Vanilla JS](https://github.com/hodgef/simple-keyboard)
- [Angular](https://simple-keyboard.com/demo)
- [Vue.js](https://simple-keyboard.com/demo)

### Questions? Join the chat

<a href="https://discordapp.com/invite/SJexsCG" title="Join our Discord chat" target="_blank"><img src="https://discordapp.com/api/guilds/498978399801573396/widget.png?style=banner2" align="center"></a>

## 🎯 Compatibility

- Internet Explorer 11
- Edge (Spartan) 16+
- Edge (Anaheim/Edge Chromium) 79+
- Chrome 49+
- Safari 9+
- Firefox 57+
- iOS 9+

> Note: If you don't want to support old browsers, you can use the Modern Browsers bundle ([index.modern.js](https://github.com/hodgef/react-simple-keyboard/blob/master/build)).

## ✅ Contributing

PRs and issues are welcome. Feel free to submit any issues you have at:
[https://github.com/hodgef/react-simple-keyboard/issues](https://github.com/hodgef/react-simple-keyboard/issues)
